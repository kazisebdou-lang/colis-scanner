# Colis Scanner — App Android

App Android (Kotlin + Jetpack Compose) qui reproduit le workflow demandé :

📱 Ouvrir l'app → 📷 Une seule photo du bon → 🤖 Analyse automatique (OCR sur
l'appareil, hors ligne, via ML Kit) → 💾 Enregistrement automatique → 📦 Colis
en stock.

## Ce que fait l'app

- **Une seule photo** du bon suffit (CameraX).
- **ML Kit Text Recognition** (gratuit, 100% hors ligne) lit tout le texte de
  la photo.
- Un module d'analyse maison (`BonParser.kt`) transforme ce texte brut en
  champs structurés : Tracking, Référence, Destinataire, Téléphone, C.R.,
  N° colis, Date, Départ, Destination, Transporteur.
- **Distinction C.R. / Prix de livraison manuscrit** : le C.R. est repéré via
  le libellé imprimé "C.R.". Le prix de livraison (écrit au stylo) est repéré
  par mots-clés ("Prix"/"Livraison") ou, à défaut, comme le plus petit nombre
  isolé restant sur le bon. Si la détection n'est pas fiable, le champ est
  marqué **⚠️ Vérifier le prix** et reste modifiable — c'est le seul champ que
  l'utilisateur doit normalement toucher.
- **Enregistrement automatique** dans une base locale (Room) après validation
  → apparaît dans "Colis en stock".

## Structure du projet

```
ColisApp/
├── app/src/main/java/com/colis/app/
│   ├── MainActivity.kt          # Navigation simple entre les 4 écrans
│   ├── ColisApplication.kt
│   ├── ui/                      # Écrans Compose (caméra, vérification, stock, détail)
│   ├── ocr/                     # OcrProcessor (ML Kit) + BonParser (extraction)
│   ├── data/                    # Entité Room, DAO, Database, Repository
│   └── viewmodel/               # ColisViewModel
```

## Comment ouvrir et lancer le projet

Vous n'avez pas encore Android Studio — voici les étapes :

1. **Installer Android Studio** (gratuit) : https://developer.android.com/studio
   Suivez l'installateur par défaut (il installe aussi le SDK Android).
2. **Ouvrir le projet** : `Open` → sélectionnez le dossier `ColisApp` (celui
   qui contient `settings.gradle`).
3. Attendez la synchronisation Gradle (Android Studio télécharge les
   dépendances automatiquement — connexion internet nécessaire **une seule
   fois**, pour build ; l'app elle-même fonctionne ensuite hors ligne).
4. Branchez un téléphone Android (mode développeur + débogage USB activé) ou
   créez un émulateur, puis cliquez sur **Run ▶**.

## Personnalisation à prévoir

Le parsing (`BonParser.kt`) utilise des règles génériques (mots-clés +
position). Selon le modèle exact de bon que vous utilisez (Yalidine, ZR
Express, etc.), il faudra probablement ajuster :

- La liste de mots-clés reconnus pour chaque libellé.
- Le seuil de montant utilisé pour deviner le prix de livraison (actuellement
  "le plus petit nombre isolé restant").

Le plus simple est de tester avec 5-10 photos réelles de vos bons, de noter
les cas où un champ est mal extrait, puis d'ajuster les règles correspondantes
dans `BonParser.kt`.
