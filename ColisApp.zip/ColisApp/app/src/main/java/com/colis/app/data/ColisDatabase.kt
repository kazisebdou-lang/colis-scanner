package com.colis.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [Colis::class], version = 1, exportSchema = false)
abstract class ColisDatabase : RoomDatabase() {

    abstract fun colisDao(): ColisDao

    companion object {
        @Volatile
        private var INSTANCE: ColisDatabase? = null

        fun getInstance(context: Context): ColisDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    ColisDatabase::class.java,
                    "colis_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
