package com.colis.app.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ColisDao {

    @Query("SELECT * FROM colis ORDER BY dateEnregistrement DESC")
    fun getAll(): Flow<List<Colis>>

    @Query("SELECT * FROM colis WHERE id = :id")
    fun getById(id: Long): Flow<Colis?>

    @Query("SELECT * FROM colis WHERE tracking = :tracking LIMIT 1")
    suspend fun findByTracking(tracking: String): Colis?

    @Insert
    suspend fun insert(colis: Colis): Long

    @Update
    suspend fun update(colis: Colis)

    @Delete
    suspend fun delete(colis: Colis)
}
