package com.colis.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.colis.app.ocr.BonExtractionResult

@Composable
fun ReviewScreen(
    extraction: BonExtractionResult,
    onFieldChange: (BonExtractionResult) -> Unit,
    onConfirmSave: () -> Unit,
    onRetakePhoto: () -> Unit
) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("Vérification du bon", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(
            "Les champs ci-dessous ont été détectés automatiquement. Corrigez uniquement si nécessaire.",
            style = MaterialTheme.typography.bodySmall
        )
        Spacer(Modifier.height(12.dp))

        AsyncImage(
            model = extraction.photoPath,
            contentDescription = "Photo du bon",
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
        )

        Spacer(Modifier.height(16.dp))

        LabeledField("Tracking #", extraction.tracking) { onFieldChange(extraction.copy(tracking = it)) }
        LabeledField("Référence", extraction.reference) { onFieldChange(extraction.copy(reference = it)) }
        LabeledField("Créé le", extraction.dateCreation) { onFieldChange(extraction.copy(dateCreation = it)) }
        LabeledField("Numéro de colis", extraction.numeroColis) { onFieldChange(extraction.copy(numeroColis = it)) }
        LabeledField("Type", extraction.type) { onFieldChange(extraction.copy(type = it)) }
        LabeledField("Statut paiement", extraction.statutPaiement) { onFieldChange(extraction.copy(statutPaiement = it)) }
        LabeledField("Code zone", extraction.codeZone) { onFieldChange(extraction.copy(codeZone = it)) }
        LabeledField("Total", extraction.total) { onFieldChange(extraction.copy(total = it)) }
        LabeledField("C.R.", extraction.cr) { onFieldChange(extraction.copy(cr = it)) }

        Spacer(Modifier.height(4.dp))
        Divider()
        Spacer(Modifier.height(8.dp))
        Text("Expéditeur", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        LabeledField("Nom", extraction.expediteurNom) { onFieldChange(extraction.copy(expediteurNom = it)) }
        LabeledField("Téléphone", extraction.expediteurTelephone) { onFieldChange(extraction.copy(expediteurTelephone = it)) }
        LabeledField("Départ (ville)", extraction.depart) { onFieldChange(extraction.copy(depart = it)) }

        Spacer(Modifier.height(4.dp))
        Divider()
        Spacer(Modifier.height(8.dp))
        Text("Destinataire", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        LabeledField("Nom", extraction.destinataireNom) { onFieldChange(extraction.copy(destinataireNom = it)) }
        LabeledField("Téléphone", extraction.destinataireTelephone) { onFieldChange(extraction.copy(destinataireTelephone = it)) }
        LabeledField("Destination (ville)", extraction.destination) { onFieldChange(extraction.copy(destination = it)) }

        Spacer(Modifier.height(4.dp))
        Divider()
        Spacer(Modifier.height(8.dp))
        LabeledField("Remarque", extraction.remarque) { onFieldChange(extraction.copy(remarque = it)) }

        Spacer(Modifier.height(8.dp))
        Divider()
        Spacer(Modifier.height(8.dp))

        // Champ spécial : prix de livraison manuscrit
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                if (extraction.prixLivraisonIncertain) "⚠️ Vérifier le prix" else "Prix de livraison",
                style = MaterialTheme.typography.labelLarge,
                color = if (extraction.prixLivraisonIncertain) Color(0xFFB25E00) else MaterialTheme.colorScheme.onSurface,
                fontWeight = FontWeight.Bold
            )
        }
        OutlinedTextField(
            value = extraction.prixLivraison,
            onValueChange = { onFieldChange(extraction.copy(prixLivraison = it, prixLivraisonIncertain = false)) },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("ex: 300 DA") },
            colors = if (extraction.prixLivraisonIncertain) OutlinedTextFieldDefaults.colors(
                unfocusedBorderColor = Color(0xFFB25E00)
            ) else OutlinedTextFieldDefaults.colors()
        )

        Spacer(Modifier.height(24.dp))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = onRetakePhoto, modifier = Modifier.weight(1f)) {
                Text("Reprendre la photo")
            }
            Button(onClick = onConfirmSave, modifier = Modifier.weight(1f)) {
                Text("Enregistrer")
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun LabeledField(label: String, value: String, onChange: (String) -> Unit) {
    Column(Modifier.padding(bottom = 10.dp)) {
        Text(label, style = MaterialTheme.typography.labelMedium)
        OutlinedTextField(
            value = value,
            onValueChange = onChange,
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
    }
}
