package com.colis.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.colis.app.data.Colis

@Composable
fun ColisDetailScreen(
    colis: Colis,
    onBack: () -> Unit,
    onSavePrix: (String) -> Unit,
    onDelete: () -> Unit
) {
    var prix by remember(colis.id) { mutableStateOf(colis.prixLivraison) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(colis.destinataire.ifBlank { "Colis" }) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Retour")
                    }
                },
                actions = {
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Filled.Delete, contentDescription = "Supprimer")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            Modifier
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            if (colis.photoPath.isNotBlank()) {
                AsyncImage(
                    model = colis.photoPath,
                    contentDescription = "Photo du bon",
                    modifier = Modifier.fillMaxWidth().height(200.dp)
                )
                Spacer(Modifier.height(16.dp))
            }

            DetailRow("Tracking", colis.tracking)
            DetailRow("Référence", colis.reference)
            DetailRow("Téléphone", colis.telephone)
            DetailRow("C.R.", colis.cr)
            DetailRow("N° colis", colis.nombreColis)
            DetailRow("Date", colis.date)
            DetailRow("Départ", colis.depart)
            DetailRow("Destination", colis.destination)
            DetailRow("Transporteur", colis.transporteur)

            Spacer(Modifier.height(12.dp))
            Divider()
            Spacer(Modifier.height(12.dp))

            Text(
                if (colis.prixLivraisonIncertain) "⚠️ Prix de livraison (à vérifier)" else "Prix de livraison",
                style = MaterialTheme.typography.labelLarge
            )
            OutlinedTextField(
                value = prix,
                onValueChange = { prix = it },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
            Button(onClick = { onSavePrix(prix) }, modifier = Modifier.fillMaxWidth()) {
                Text("Mettre à jour")
            }
        }
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Column(Modifier.padding(bottom = 10.dp)) {
        Text(label, style = MaterialTheme.typography.labelMedium)
        Text(value.ifBlank { "-" }, style = MaterialTheme.typography.bodyLarge)
    }
}
