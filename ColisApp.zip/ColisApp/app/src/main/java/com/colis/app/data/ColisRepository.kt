package com.colis.app.data

import kotlinx.coroutines.flow.Flow

class ColisRepository(private val dao: ColisDao) {

    val allColis: Flow<List<Colis>> = dao.getAll()

    fun getById(id: Long): Flow<Colis?> = dao.getById(id)

    suspend fun save(colis: Colis): Long = dao.insert(colis)

    suspend fun update(colis: Colis) = dao.update(colis)

    suspend fun delete(colis: Colis) = dao.delete(colis)

    suspend fun existsTracking(tracking: String): Boolean =
        tracking.isNotBlank() && dao.findByTracking(tracking) != null
}
