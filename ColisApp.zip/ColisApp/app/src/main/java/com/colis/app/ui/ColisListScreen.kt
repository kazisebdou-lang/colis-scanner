package com.colis.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.colis.app.data.Colis

@Composable
fun ColisListScreen(
    colisList: List<Colis>,
    onAddClick: () -> Unit,
    onItemClick: (Colis) -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Colis en stock (${colisList.size})") })
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onAddClick) {
                Icon(Icons.Filled.Add, contentDescription = "Scanner un bon")
            }
        }
    ) { padding ->
        if (colisList.isEmpty()) {
            Column(
                Modifier
                    .fillMaxSize()
                    .padding(padding),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(Icons.Filled.Inventory2, contentDescription = null, modifier = Modifier.size(64.dp))
                Spacer(Modifier.height(12.dp))
                Text("Aucun colis pour le moment")
                Text("Appuyez sur + pour scanner un bon", style = MaterialTheme.typography.bodySmall)
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.padding(padding)
            ) {
                items(colisList, key = { it.id }) { colis ->
                    ColisCard(colis) { onItemClick(colis) }
                }
            }
        }
    }
}

@Composable
private fun ColisCard(colis: Colis, onClick: () -> Unit) {
    ElevatedCard(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    colis.destinataireNom.ifBlank { "Destinataire inconnu" },
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                if (colis.prixLivraisonIncertain) {
                    Text("⚠️", style = MaterialTheme.typography.titleMedium)
                }
            }
            Spacer(Modifier.height(4.dp))
            Text("Tracking : ${colis.tracking.ifBlank { "-" }}", style = MaterialTheme.typography.bodySmall)
            Text("N° colis : ${colis.numeroColis.ifBlank { "-" }} · ${colis.type.ifBlank { "-" }}", style = MaterialTheme.typography.bodySmall)
            Text("${colis.depart.ifBlank { "?" }} → ${colis.destination.ifBlank { "?" }}", style = MaterialTheme.typography.bodySmall)
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("C.R. : ${colis.cr.ifBlank { "-" }}", style = MaterialTheme.typography.bodySmall)
                Text(
                    "Livraison : ${colis.prixLivraison.ifBlank { "-" }}",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (colis.prixLivraisonIncertain) Color(0xFFB25E00) else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
