package com.colis.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Un colis enregistré à partir d'un bon scanné.
 * `prixLivraisonIncertain` indique que la reconnaissance du montant manuscrit
 * n'est pas fiable à 100% et que l'utilisateur devrait la vérifier.
 */
@Entity(tableName = "colis")
data class Colis(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val tracking: String = "",
    val reference: String = "",
    val destinataire: String = "",
    val telephone: String = "",
    val cr: String = "",              // Contre-Remboursement (C.R.), imprimé
    val nombreColis: String = "",     // ex: 1/1
    val date: String = "",
    val depart: String = "",
    val destination: String = "",
    val transporteur: String = "",
    val prixLivraison: String = "",   // Montant manuscrit détecté
    val prixLivraisonIncertain: Boolean = false,
    val photoPath: String = "",
    val dateEnregistrement: Long = System.currentTimeMillis()
)
