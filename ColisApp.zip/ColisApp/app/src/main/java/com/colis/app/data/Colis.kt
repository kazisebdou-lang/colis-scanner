package com.colis.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Un colis enregistré à partir d'un bon KAZI TOUR scanné.
 */
@Entity(tableName = "colis")
data class Colis(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val tracking: String = "",
    val reference: String = "",
    val dateCreation: String = "",
    val numeroColis: String = "",
    val type: String = "",
    val statutPaiement: String = "",
    val total: String = "",
    val cr: String = "",
    val codeZone: String = "",
    val expediteurNom: String = "",
    val expediteurTelephone: String = "",
    val destinataireNom: String = "",
    val destinataireTelephone: String = "",
    val depart: String = "",
    val destination: String = "",
    val remarque: String = "",
    val prixLivraison: String = "",
    val prixLivraisonIncertain: Boolean = false,
    val photoPath: String = "",
    val dateEnregistrement: Long = System.currentTimeMillis()
)
