package com.colis.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.colis.app.data.ColisDatabase
import com.colis.app.data.ColisRepository
import com.colis.app.ui.CameraScreen
import com.colis.app.ui.ColisDetailScreen
import com.colis.app.ui.ColisListScreen
import com.colis.app.ui.ReviewScreen
import com.colis.app.ui.theme.ColisAppTheme
import com.colis.app.viewmodel.ColisViewModel
import com.colis.app.viewmodel.ColisViewModelFactory

private sealed class Screen {
    data object Stock : Screen()
    data object Camera : Screen()
    data object Review : Screen()
    data class Detail(val colisId: Long) : Screen()
}

class MainActivity : ComponentActivity() {

    private val viewModel: ColisViewModel by viewModels {
        val db = ColisDatabase.getInstance(applicationContext)
        ColisViewModelFactory(ColisRepository(db.colisDao()))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ColisAppTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AppRoot(viewModel)
                }
            }
        }
    }
}

@Composable
private fun AppRoot(viewModel: ColisViewModel) {
    var screen by remember { mutableStateOf<Screen>(Screen.Stock) }

    val extraction by viewModel.extraction.collectAsState()
    val isProcessing by viewModel.isProcessing.collectAsState()
    val colisList by viewModel.colisList.collectAsState(initial = emptyList())

    // Dès que l'analyse d'une nouvelle photo est prête, on bascule sur l'écran de vérification.
    LaunchedEffect(extraction) {
        if (extraction != null && screen == Screen.Camera) {
            screen = Screen.Review
        }
    }

    when (val s = screen) {
        Screen.Stock -> ColisListScreen(
            colisList = colisList,
            onAddClick = {
                viewModel.clearExtraction()
                screen = Screen.Camera
            },
            onItemClick = { colis -> screen = Screen.Detail(colis.id) }
        )

        Screen.Camera -> CameraScreen(
            isProcessing = isProcessing,
            onPhotoCaptured = { file -> viewModel.processPhoto(file) }
        )

        Screen.Review -> {
            val current = extraction
            if (current == null) {
                screen = Screen.Camera
            } else {
                ReviewScreen(
                    extraction = current,
                    onFieldChange = { viewModel.updateExtraction(it) },
                    onConfirmSave = {
                        viewModel.saveCurrentExtraction { screen = Screen.Stock }
                    },
                    onRetakePhoto = {
                        viewModel.clearExtraction()
                        screen = Screen.Camera
                    }
                )
            }
        }

        is Screen.Detail -> {
            val colis = colisList.firstOrNull { it.id == s.colisId }
            if (colis == null) {
                screen = Screen.Stock
            } else {
                ColisDetailScreen(
                    colis = colis,
                    onBack = { screen = Screen.Stock },
                    onSavePrix = { newPrix ->
                        viewModel.updatePrix(colis, newPrix)
                        screen = Screen.Stock
                    },
                    onDelete = {
                        viewModel.deleteColis(colis)
                        screen = Screen.Stock
                    }
                )
            }
        }
    }
}
