package com.colis.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.colis.app.data.Colis
import com.colis.app.data.ColisRepository
import com.colis.app.ocr.BonExtractionResult
import com.colis.app.ocr.BonParser
import com.colis.app.ocr.OcrProcessor
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.io.File

class ColisViewModel(private val repository: ColisRepository) : ViewModel() {

    val colisList = repository.allColis

    private val _extraction = MutableStateFlow<BonExtractionResult?>(null)
    val extraction: StateFlow<BonExtractionResult?> = _extraction

    private val _isProcessing = MutableStateFlow(false)
    val isProcessing: StateFlow<Boolean> = _isProcessing

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    /** Étape 1 : la photo vient d'être prise -> on lance l'analyse automatique. */
    fun processPhoto(photoFile: File) {
        _isProcessing.value = true
        _error.value = null
        viewModelScope.launch {
            try {
                val text = OcrProcessor.recognize(photoFile)
                val result = BonParser.parse(text, photoFile.absolutePath)
                _extraction.value = result
            } catch (e: Exception) {
                _error.value = "Erreur d'analyse : ${e.message}"
            } finally {
                _isProcessing.value = false
            }
        }
    }

    /** L'utilisateur corrige un champ (normalement seulement le prix de livraison). */
    fun updateExtraction(updated: BonExtractionResult) {
        _extraction.value = updated
    }

    fun clearExtraction() {
        _extraction.value = null
    }

    /** Étape finale : enregistrement automatique dans le stock. */
    fun saveCurrentExtraction(onSaved: () -> Unit) {
        val e = _extraction.value ?: return
        viewModelScope.launch {
            repository.save(
                Colis(
                    tracking = e.tracking,
                    reference = e.reference,
                    dateCreation = e.dateCreation,
                    numeroColis = e.numeroColis,
                    type = e.type,
                    statutPaiement = e.statutPaiement,
                    total = e.total,
                    cr = e.cr,
                    codeZone = e.codeZone,
                    expediteurNom = e.expediteurNom,
                    expediteurTelephone = e.expediteurTelephone,
                    destinataireNom = e.destinataireNom,
                    destinataireTelephone = e.destinataireTelephone,
                    depart = e.depart,
                    destination = e.destination,
                    remarque = e.remarque,
                    prixLivraison = e.prixLivraison,
                    prixLivraisonIncertain = e.prixLivraisonIncertain,
                    photoPath = e.photoPath
                )
            )
            _extraction.value = null
            onSaved()
        }
    }

    fun deleteColis(colis: Colis) {
        viewModelScope.launch { repository.delete(colis) }
    }

    /** Correction manuelle du prix de livraison sur un colis déjà enregistré. */
    fun updatePrix(colis: Colis, newPrix: String) {
        viewModelScope.launch {
            repository.update(colis.copy(prixLivraison = newPrix, prixLivraisonIncertain = false))
        }
    }
}
