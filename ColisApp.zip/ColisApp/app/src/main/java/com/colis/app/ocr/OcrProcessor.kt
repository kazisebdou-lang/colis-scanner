package com.colis.app.ocr

import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.mlkit.vision.text.Text
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Reconnaissance de texte 100% sur l'appareil (hors ligne), via ML Kit.
 */
object OcrProcessor {

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    suspend fun recognize(photoFile: File): Text = suspendCancellableCoroutine { cont ->
        try {
            val image = InputImage.fromFilePath(
                /* context = */ com.colis.app.ColisApplication.appContext,
                /* imageUri = */ android.net.Uri.fromFile(photoFile)
            )
            recognizer.process(image)
                .addOnSuccessListener { text -> cont.resume(text) }
                .addOnFailureListener { e -> cont.resumeWithException(e) }
        } catch (e: Exception) {
            cont.resumeWithException(e)
        }
    }
}
