package com.colis.app.ui.theme

import androidx.compose.ui.graphics.Color

val Primary = Color(0xFF1565C0)
val PrimaryDark = Color(0xFF0D47A1)
val Secondary = Color(0xFFFF8F00)
val Background = Color(0xFFF7F8FA)
