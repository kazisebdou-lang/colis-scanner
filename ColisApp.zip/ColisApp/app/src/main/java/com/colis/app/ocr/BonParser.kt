package com.colis.app.ocr

import android.graphics.Rect
import com.google.mlkit.vision.text.Text
import java.text.Normalizer

/**
 * Transforme le résultat brut de ML Kit en champs structurés, calibré sur le
 * format réel des bons KAZI TOUR :
 *
 *   Tracking #: 9319729
 *   Référence: 1-9359569-9319729         Numéro de Colis: 1/1
 *   Créé le: 2026-09-14 12:03:58         Type: Carton
 *                                        Non-Payé
 *   [ 13-19/1 ]                          (QR code)
 *   Total : 0                            C.R : 0
 *   Expéditeur                           Destinataire
 *   CHOUAIB GUERDA                       abderahmane hafs
 *   0794046178                           0660982881
 *   SIDI MHAMMED B ZOUAR      -->        SEBDOU
 *   Remarque : ...
 *   Prix de livraison : [manuscrit]
 *
 * Le C.R. (imprimé) et le Prix de livraison (manuscrit, champ dédié) sont
 * deux montants différents et ne doivent jamais être confondus.
 */
object BonParser {

    private data class OcrLine(val text: String, val box: Rect?)

    private val phoneRegex = Regex("""\b0\d{9}\b""")
    private val dateTimeRegex = Regex("""\b\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}\b""")
    private val numeroColisRegex = Regex("""\b(\d{1,2})\s?/\s?(\d{1,2})\b""")
    private val referenceRegex = Regex("""\b\d-\d{5,}-\d{5,}\b""")
    private val codeZoneRegex = Regex("""\b\d{1,3}-\d{1,3}\s?/\s?\d{1,2}\b""")
    private val amountRegex = Regex("""\d{1,3}(?:[ .]\d{3})*|\d+""")

    fun parse(text: Text, photoPath: String): BonExtractionResult {
        val lines = text.textBlocks
            .flatMap { it.lines }
            .map { OcrLine(it.text.trim(), it.boundingBox) }
            .filter { it.text.isNotBlank() }
            .sortedBy { it.box?.top ?: 0 }

        val fullText = lines.joinToString("\n") { it.text }
        val normFullText = normalize(fullText)

        val tracking = findAfterLabel(lines, listOf("tracking"))
            ?.let { Regex("""\d{5,}""").find(it)?.value } ?: ""

        val reference = referenceRegex.find(fullText)?.value ?: ""

        val dateCreation = dateTimeRegex.find(fullText)?.value ?: ""

        val numeroColis = findAfterLabel(lines, listOf("numero de colis", "n de colis", "colis"))
            ?.let { numeroColisRegex.find(it)?.value }
            ?: numeroColisRegex.find(fullText)?.value ?: ""

        val type = findAfterLabel(lines, listOf("type"))?.trim() ?: ""

        val statutPaiement = when {
            normFullText.contains("non-paye") || normFullText.contains("non paye") -> "Non-Payé"
            normFullText.contains("paye") -> "Payé"
            else -> ""
        }

        val total = findAmountAfterLabel(lines, listOf("total"))

        val cr = findAmountAfterLabel(lines, listOf("c.r", "cr "))

        val codeZone = codeZoneRegex.find(fullText)?.value?.replace(" ", "") ?: ""

        // --- Expéditeur : nom + téléphone ---
        val expediteurBlock = extractPersonBlock(lines, listOf("expediteur"))
        // --- Destinataire : nom + téléphone ---
        val destinataireBlock = extractPersonBlock(lines, listOf("destinataire"))

        // --- Départ / Destination (villes) ---
        val depart = findAfterLabel(lines, listOf("location"))
            ?: guessCityNear(lines, expediteurBlock.lastLineIndex)

        val destination = guessCityNear(lines, destinataireBlock.lastLineIndex)
            ?: run {
                // à défaut, la dernière ligne "ville" (tout en majuscules, courte, sans chiffres)
                lines.lastOrNull { isLikelyCityLine(it.text) }?.text
            } ?: ""

        val remarque = findAfterLabel(lines, listOf("remarque")) ?: ""

        // --- Prix de livraison : champ dédié, à remplir à la main ---
        val (prix, incertain) = findPrixLivraison(lines)

        return BonExtractionResult(
            tracking = tracking,
            reference = reference,
            dateCreation = dateCreation,
            numeroColis = numeroColis,
            type = type,
            statutPaiement = statutPaiement,
            total = total,
            cr = cr,
            codeZone = codeZone,
            expediteurNom = expediteurBlock.nom,
            expediteurTelephone = expediteurBlock.telephone,
            destinataireNom = destinataireBlock.nom,
            destinataireTelephone = destinataireBlock.telephone,
            depart = depart ?: "",
            destination = destination,
            remarque = remarque,
            prixLivraison = prix,
            prixLivraisonIncertain = incertain,
            rawText = fullText,
            photoPath = photoPath
        )
    }

    private data class PersonBlock(val nom: String, val telephone: String, val lastLineIndex: Int)

    /**
     * Cherche un libellé ("Expéditeur", "Destinataire", ...) puis extrait le nom
     * et le téléphone dans la même ligne ou les 1-2 lignes suivantes.
     */
    private fun extractPersonBlock(lines: List<OcrLine>, labels: List<String>): PersonBlock {
        for ((index, line) in lines.withIndex()) {
            val norm = normalize(line.text)
            if (labels.none { norm.contains(it) }) continue

            // Cas "Destinataire : SAHI NOUH 0771095425" (tout sur la même ligne)
            val sameLinePhone = phoneRegex.find(line.text)
            if (sameLinePhone != null) {
                val nom = removeLabelFromText(line.text, labels.first { norm.contains(it) })
                    .replace(sameLinePhone.value, "")
                    .trim(':', ' ', '-')
                return PersonBlock(nom.trim(), sameLinePhone.value, index)
            }

            // Cas multi-lignes : Label / Nom / Téléphone
            var nom = ""
            var telephone = ""
            var lastIndex = index
            for (offset in 1..3) {
                val next = lines.getOrNull(index + offset) ?: break
                val phoneMatch = phoneRegex.find(next.text)
                if (phoneMatch != null) {
                    telephone = phoneMatch.value
                    lastIndex = index + offset
                    break
                } else if (nom.isBlank()) {
                    nom = next.text
                    lastIndex = index + offset
                }
            }
            return PersonBlock(nom.trim(), telephone, lastIndex)
        }
        return PersonBlock("", "", -1)
    }

    /** Ligne "ville" juste après un bloc (nom+téléphone) : texte court, sans chiffres. */
    private fun guessCityNear(lines: List<OcrLine>, afterIndex: Int): String? {
        if (afterIndex < 0) return null
        for (offset in 1..2) {
            val candidate = lines.getOrNull(afterIndex + offset) ?: continue
            if (isLikelyCityLine(candidate.text)) return candidate.text.trim()
        }
        return null
    }

    private fun isLikelyCityLine(text: String): Boolean {
        val t = text.trim()
        if (t.isEmpty() || t.length > 40) return false
        if (t.any { it.isDigit() }) return false
        val norm = normalize(t)
        val forbidden = listOf("remarque", "expediteur", "destinataire", "total", "c.r", "tracking", "reference", "type", "colis", "location", "prix", "livraison")
        return forbidden.none { norm.contains(it) }
    }

    /** Cherche une ligne contenant un des libellés et retourne ce qui suit sur la même ligne (ou la ligne suivante). */
    private fun findAfterLabel(lines: List<OcrLine>, labels: List<String>): String? {
        for ((index, line) in lines.withIndex()) {
            val norm = normalize(line.text)
            val matched = labels.firstOrNull { norm.contains(it) } ?: continue

            val sepIdx = line.text.indexOfFirst { it == ':' }
            if (sepIdx != -1 && sepIdx + 1 < line.text.length) {
                val after = line.text.substring(sepIdx + 1).trim()
                if (after.isNotBlank()) return after
            }

            val withoutLabel = removeLabelFromText(line.text, matched)
            if (withoutLabel.isNotBlank()) return withoutLabel

            val next = lines.getOrNull(index + 1)
            if (next != null && labels.none { normalize(next.text).contains(it) }) return next.text
        }
        return null
    }

    private fun findAmountAfterLabel(lines: List<OcrLine>, labels: List<String>): String {
        val value = findAfterLabel(lines, labels) ?: return ""
        val amount = amountRegex.find(value) ?: return ""
        return amount.value.trim()
    }

    private fun removeLabelFromText(original: String, label: String): String {
        val norm = normalize(original)
        val start = norm.indexOf(label)
        if (start == -1) return ""
        val result = original.removeRange(
            start.coerceAtMost(original.length),
            (start + label.length).coerceAtMost(original.length)
        )
        return result.trim(':', ' ', '-', '#')
    }

    /**
     * Le bon KAZI TOUR imprime un libellé dédié "Prix de livraison :" laissé
     * vide pour être rempli au stylo. On cherche ce libellé puis on lit le
     * montant écrit juste après (sur la même ligne ou la ligne suivante).
     * Si rien n'est trouvé après le libellé, le champ reste vide et incertain
     * (l'utilisateur doit le remplir lui-même après vérification visuelle).
     */
    private fun findPrixLivraison(lines: List<OcrLine>): Pair<String, Boolean> {
        for ((index, line) in lines.withIndex()) {
            val norm = normalize(line.text)
            if (!norm.contains("prix") && !norm.contains("livraison") && !norm.contains("price")) continue

            // Montant sur la même ligne que le libellé
            val sepIdx = line.text.indexOfFirst { it == ':' }
            if (sepIdx != -1) {
                val after = line.text.substring(sepIdx + 1).trim()
                val amount = amountRegex.find(after)
                if (amount != null && amount.value.isNotBlank()) {
                    return formatAmount(amount.value) to false
                }
            }

            // Montant sur la ligne suivante (souvent le cas pour une valeur manuscrite)
            val next = lines.getOrNull(index + 1)
            if (next != null) {
                val nextNorm = normalize(next.text)
                val isAnotherLabel = listOf("remarque", "destinataire", "expediteur", "total", "c.r").any { nextNorm.contains(it) }
                val amount = amountRegex.find(next.text)
                if (!isAnotherLabel && amount != null) {
                    return formatAmount(amount.value) to false
                }
            }

            // Libellé trouvé mais rien de lisible après : à vérifier manuellement
            return "" to true
        }
        // Le libellé "Prix de livraison" n'a même pas été détecté sur la photo
        return "" to true
    }

    private fun formatAmount(raw: String): String {
        val digits = raw.trim()
        return if (digits.contains("DA", ignoreCase = true)) digits else "$digits DA"
    }

    private fun normalize(input: String): String {
        val temp = Normalizer.normalize(input, Normalizer.Form.NFD)
            .replace(Regex("\\p{M}"), "")
        return temp.lowercase().trim()
    }
}
