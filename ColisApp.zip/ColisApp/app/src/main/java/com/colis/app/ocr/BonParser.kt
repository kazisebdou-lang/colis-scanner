package com.colis.app.ocr

import android.graphics.Rect
import com.google.mlkit.vision.text.Text
import java.text.Normalizer

/**
 * Transforme le résultat brut de ML Kit en champs structurés.
 *
 * Point important : le C.R. (Contre-Remboursement, imprimé sur le bon) et le
 * Prix de livraison (écrit à la main) sont deux montants différents. On les
 * distingue par mots-clés ("C.R." vs "Prix"/"Livraison") et, à défaut, par
 * position/forme (le prix manuscrit est en général un nombre isolé, de faible
 * valeur, sans le suffixe imprimé "DA" aligné avec un libellé).
 */
object BonParser {

    private data class OcrLine(val text: String, val box: Rect?)

    private val amountRegex = Regex("""\d{1,3}(?:[ .]\d{3})*|\d+""")
    private val phoneRegex = Regex("""\b0\d{9}\b""")
    private val dateRegex = Regex("""\b\d{1,2}/\d{1,2}/\d{2,4}\b""")
    private val nColisRegex = Regex("""\b(\d{1,2})\s?/\s?(\d{1,2})\b""")
    private val referenceRegex = Regex("""\b\d[\d\-A-Za-z]{4,}\b""")

    fun parse(text: Text, photoPath: String): BonExtractionResult {
        // On aplatit tous les blocs en lignes, triées approximativement dans
        // l'ordre de lecture (haut -> bas).
        val lines = text.textBlocks
            .flatMap { it.lines }
            .map { OcrLine(it.text.trim(), it.boundingBox) }
            .filter { it.text.isNotBlank() }
            .sortedBy { it.box?.top ?: 0 }

        val fullText = lines.joinToString("\n") { it.text }

        val destinataire = findLabelValue(lines, listOf("destinataire"))
        val telephone = phoneRegex.find(fullText)?.value
            ?: findLabelValue(lines, listOf("telephone", "tel", "tél"))
        val date = dateRegex.find(fullText)?.value ?: ""
        val depart = findLabelValue(lines, listOf("depart", "départ"))
        val destination = findLabelValue(lines, listOf("destination"))
        val transporteur = findLabelValue(lines, listOf("transporteur"))
        val tracking = findLabelValue(lines, listOf("tracking"))
            ?.let { amountRegex.find(it)?.value } ?: ""
        val reference = findLabelValue(lines, listOf("reference", "référence", "ref"))
            ?.let { referenceRegex.find(it)?.value } ?: ""
        val nColisLine = findLabelValue(lines, listOf("colis", "n° colis", "nb colis"))
        val nombreColis = nColisLine?.let { nColisRegex.find(it)?.value }
            ?: nColisRegex.find(fullText)?.value ?: ""

        // --- C.R. (imprimé) ---
        val crLine = lines.firstOrNull { normalize(it.text).contains("c.r") || normalize(it.text).contains(" cr ") || normalize(it.text).startsWith("cr") }
        val cr = crLine?.let { extractAmount(it.text) } ?: ""
        val crBox = crLine?.box

        // --- Prix de livraison (manuscrit) ---
        val (prix, incertain) = findPrixLivraison(lines, crBox, cr, telephone, date)

        return BonExtractionResult(
            tracking = tracking,
            reference = reference,
            destinataire = destinataire ?: "",
            telephone = telephone ?: "",
            cr = cr,
            nombreColis = nombreColis,
            date = date,
            depart = depart ?: "",
            destination = destination ?: "",
            transporteur = transporteur ?: "",
            prixLivraison = prix,
            prixLivraisonIncertain = incertain,
            rawText = fullText,
            photoPath = photoPath
        )
    }

    /** Cherche une ligne contenant un des libellés et retourne la valeur associée. */
    private fun findLabelValue(lines: List<OcrLine>, labels: List<String>): String? {
        for ((index, line) in lines.withIndex()) {
            val norm = normalize(line.text)
            val matchedLabel = labels.firstOrNull { norm.contains(it) } ?: continue

            // Cas 1 : "Label : Valeur" ou "Label -> Valeur" sur la même ligne
            val sepIdx = line.text.indexOfFirst { it == ':' || it == '→' || it == '-' }
            if (sepIdx != -1 && sepIdx + 1 < line.text.length) {
                val after = line.text.substring(sepIdx + 1).trim()
                if (after.isNotBlank() && !normalize(after).let { it in labels }) return after
            }

            // Cas 2 : le libellé seul, on retire juste le mot-clé du texte de la ligne
            val withoutLabel = removeLabelFromText(line.text, matchedLabel)
            if (withoutLabel.isNotBlank()) return withoutLabel

            // Cas 3 : la valeur est sur la ligne suivante
            if (index + 1 < lines.size) {
                val next = lines[index + 1]
                if (!labels.any { normalize(next.text).contains(it) }) return next.text
            }
        }
        return null
    }

    private fun removeLabelFromText(original: String, label: String): String {
        val norm = normalize(original)
        val start = norm.indexOf(label)
        if (start == -1) return ""
        val result = original.removeRange(
            start.coerceAtMost(original.length),
            (start + label.length).coerceAtMost(original.length)
        )
        return result.trim(':', ' ', '-', '→')
    }

    private fun extractAmount(text: String): String {
        val cleaned = text.replace(Regex("(?i)DA"), "DA")
        val match = amountRegex.findAll(cleaned).maxByOrNull { it.value.replace(Regex("[ .]"), "").length }
        return match?.let { "${it.value.trim()} DA" } ?: ""
    }

    /**
     * Cherche le prix manuscrit : un nombre isolé qui n'est ni le C.R., ni le
     * téléphone, ni la date, ni un numéro de colis. On privilégie un nombre
     * proche du mot "prix" ou "livraison" (confiance haute) ; à défaut, le
     * plus petit nombre isolé restant, marqué comme incertain.
     */
    private fun findPrixLivraison(
        lines: List<OcrLine>,
        crBox: Rect?,
        crValue: String,
        telephone: String?,
        date: String
    ): Pair<String, Boolean> {
        // 1) Priorité : un nombre sur/à côté d'une ligne contenant "prix" ou "livraison"
        val prixLabelLine = lines.firstOrNull {
            val n = normalize(it.text)
            n.contains("prix") || (n.contains("livraison") && !n.contains("date"))
        }
        if (prixLabelLine != null) {
            val amount = amountRegex.find(prixLabelLine.text)
            if (amount != null) {
                return formatAmount(amount.value) to false
            }
            // Le libellé est présent mais vide (champ à remplir à la main) :
            // on cherche le nombre isolé le plus proche verticalement, en dessous.
            val candidate = nearestStandaloneAmount(lines, prixLabelLine.box, exclude = setOf(crValue))
            if (candidate != null) return formatAmount(candidate) to false
        }

        // 2) Sinon : on cherche tous les nombres isolés (une ligne = juste un nombre,
        //    éventuellement suivi de "DA"), en excluant ce qui est déjà identifié.
        val exclude = listOfNotNull(crValue.ifBlank { null }, telephone, date.ifBlank { null })
        val standalone = lines
            .filter { line ->
                val t = line.text.trim()
                val isIsolatedNumber = Regex("""^\d{1,6}(\s?(DA|da))?$""").matches(t)
                isIsolatedNumber && exclude.none { t.contains(it) }
            }
            .mapNotNull { amountRegex.find(it.text)?.value }
            .distinct()

        if (standalone.isEmpty()) return "" to true

        // Heuristique : le prix de livraison est en général un petit montant
        // (quelques dizaines/centaines de DA), contrairement au C.R. souvent
        // beaucoup plus élevé.
        val best = standalone.minByOrNull { it.replace(Regex("[ .]"), "").toIntOrNull() ?: Int.MAX_VALUE }
        return (best?.let { formatAmount(it) } ?: "") to true
    }

    private fun nearestStandaloneAmount(lines: List<OcrLine>, near: Rect?, exclude: Set<String>): String? {
        if (near == null) return null
        return lines
            .filter { it.box != null && it.box.top >= near.top }
            .sortedBy { kotlin.math.abs((it.box?.top ?: 0) - near.top) }
            .firstNotNullOfOrNull { line ->
                val t = line.text.trim()
                if (Regex("""^\d{1,6}(\s?(DA|da))?$""").matches(t) && exclude.none { t.contains(it) }) {
                    amountRegex.find(t)?.value
                } else null
            }
    }

    private fun formatAmount(raw: String): String {
        val digits = raw.trim()
        return if (digits.contains("DA", ignoreCase = true)) digits else "$digits DA"
    }

    private fun normalize(input: String): String {
        val temp = Normalizer.normalize(input, Normalizer.Form.NFD)
            .replace(Regex("\\p{M}"), "")
        return temp.lowercase().trim()
    }
}
