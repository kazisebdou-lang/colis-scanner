package com.colis.app.ocr

/**
 * Résultat de l'analyse automatique d'un bon de livraison.
 * Chaque champ est accompagné (quand c'est pertinent) d'un indicateur
 * de confiance pour que l'UI puisse afficher ⚠️ si besoin.
 */
data class BonExtractionResult(
    val tracking: String = "",
    val reference: String = "",
    val destinataire: String = "",
    val telephone: String = "",
    val cr: String = "",
    val nombreColis: String = "",
    val date: String = "",
    val depart: String = "",
    val destination: String = "",
    val transporteur: String = "",
    val prixLivraison: String = "",
    val prixLivraisonIncertain: Boolean = true,
    val rawText: String = "",
    val photoPath: String = ""
)
