package com.colis.app.ocr

/**
 * Résultat de l'analyse automatique d'un bon de livraison (format KAZI TOUR).
 */
data class BonExtractionResult(
    val tracking: String = "",
    val reference: String = "",
    val dateCreation: String = "",
    val numeroColis: String = "",
    val type: String = "",
    val statutPaiement: String = "",   // "Payé" ou "Non-Payé"
    val total: String = "",
    val cr: String = "",
    val codeZone: String = "",         // ex: "13-19/1"
    val expediteurNom: String = "",
    val expediteurTelephone: String = "",
    val destinataireNom: String = "",
    val destinataireTelephone: String = "",
    val depart: String = "",
    val destination: String = "",
    val remarque: String = "",
    val prixLivraison: String = "",
    val prixLivraisonIncertain: Boolean = true,
    val rawText: String = "",
    val photoPath: String = ""
)
